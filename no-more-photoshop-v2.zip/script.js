// DOM Elements
const imageUploadInput = document.getElementById('imageUpload');
const imagePreview = document.getElementById('imagePreview');
const editSection = document.getElementById('editSection');
const editPrompt = document.getElementById('editPrompt');
const editButton = document.getElementById('editButton');
const resultSection = document.getElementById('resultSection');
const resultPreview = document.getElementById('resultPreview');
const apiResponseInfo = document.getElementById('apiResponseInfo');
const apiResponseText = document.getElementById('apiResponseText');
const toggleResponseInfo = document.getElementById('toggleResponseInfo');
const downloadButton = document.getElementById('downloadButton');
const reEditButton = document.getElementById('reEditButton');
const reEditControls = document.getElementById('reEditControls');
const reEditPrompt = document.getElementById('reEditPrompt');
const applyReEditButton = document.getElementById('applyReEditButton');
const loadingIndicator = document.getElementById('loadingIndicator');
const apiKeyModal = document.getElementById('apiKeyModal');
const apiKeyInput = document.getElementById('apiKeyInput');
const saveApiKey = document.getElementById('saveApiKey');

// State variables
let originalImage = null;
let editedImage = null;
let apiKey = null;

// Fetch API key from server on load
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('/api/key');
        const data = await response.json();
        
        if (response.ok && data.key) {
            apiKey = data.key;
            console.log('API key loaded from .env file');
        } else {
            console.error('Failed to load API key from server:', data.error);
            apiKeyModal.style.display = 'flex';
        }
    } catch (error) {
        console.error('Error fetching API key:', error);
        apiKeyModal.style.display = 'flex';
    }
});

// Save manually entered API key (fallback method)
saveApiKey.addEventListener('click', () => {
    const key = apiKeyInput.value.trim();
    if (key) {
        apiKey = key;
        apiKeyModal.style.display = 'none';
    } else {
        alert('Please enter a valid API key');
    }
});

// Handle image upload
imageUploadInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        const file = e.target.files[0];
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(event) {
                originalImage = event.target.result;
                displayImage(imagePreview, originalImage);
                editSection.style.display = 'block';
                resultSection.style.display = 'none';
            };
            reader.readAsDataURL(file);
        } else {
            alert('Please upload an image file');
        }
    }
});

// Display image in container
function displayImage(container, imageSrc) {
    container.innerHTML = '';
    const img = document.createElement('img');
    img.src = imageSrc;
    container.appendChild(img);
}

// Process image edit
editButton.addEventListener('click', async () => {
    const prompt = editPrompt.value.trim();
    if (!prompt) {
        alert('Please describe the changes you want to make');
        return;
    }
    
    if (!originalImage) {
        alert('Please upload an image first');
        return;
    }
    
    if (!apiKey) {
        alert('API key is missing. Please provide your Gemini API key');
        apiKeyModal.style.display = 'flex';
        return;
    }
    
    processImageEdit(originalImage, prompt);
});

// Process re-edit
applyReEditButton.addEventListener('click', async () => {
    const prompt = reEditPrompt.value.trim();
    if (!prompt) {
        alert('Please describe the additional changes');
        return;
    }
    
    processImageEdit(editedImage || originalImage, prompt);
});

// Toggle API response info
toggleResponseInfo.addEventListener('click', () => {
    if (apiResponseInfo.style.display === 'none') {
        apiResponseInfo.style.display = 'block';
        toggleResponseInfo.textContent = 'Hide API Details';
    } else {
        apiResponseInfo.style.display = 'none';
        toggleResponseInfo.textContent = 'Show API Details';
    }
});

// Main image processing function
async function processImageEdit(image, prompt) {
    loadingIndicator.style.display = 'flex';
    apiResponseInfo.style.display = 'none';
    apiResponseText.textContent = '';
    
    try {
        // Prepare image data
        const base64Image = image.split(',')[1]; // Remove data URL prefix
        const mimeType = image.split(';')[0].split(':')[1]; // Extract mime type from data URL
        
        const enhancedPrompt = prompt + ". Please edit this image according to my instructions and return both the edited image and a brief explanation of what was changed.";
        
        // Prepare request body for Gemini API
        const requestBody = {
            contents: [
                {
                    parts: [
                        { 
                            text: enhancedPrompt
                        },
                        {
                            inline_data: {
                                mime_type: mimeType || "image/jpeg",
                                data: base64Image
                            }
                        }
                    ]
                }
            ],
            generation_config: {
                response_modalities: ["TEXT", "IMAGE"],
                temperature: 0.4,
                topP: 0.95,
                topK: 64
            }
        };
        
        console.log('Sending request to Gemini API...');
        
        // Make API request
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp-image-generation:generateContent?key=${apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });
        
        const data = await response.json();
        console.log('API Response:', data);
        
        // Display the raw API response for debugging
        apiResponseText.textContent = JSON.stringify(data, null, 2);
        
        if (response.ok) {
            // Handle successful response
            if (data.candidates && data.candidates[0].content && data.candidates[0].content.parts) {
                const parts = data.candidates[0].content.parts;
                console.log('Response parts:', parts);
                
                // Find the image part in the response
                const imagePart = parts.find(part => part.inline_data);
                
                if (imagePart && imagePart.inline_data) {
                    // Display the edited image
                    editedImage = `data:${imagePart.inline_data.mime_type};base64,${imagePart.inline_data.data}`;
                    displayImage(resultPreview, editedImage);
                    resultSection.style.display = 'block';
                    reEditControls.style.display = 'none';
                    
                    // Also display any text response if present
                    const textPart = parts.find(part => part.text);
                    if (textPart && textPart.text) {
                        console.log('API response text:', textPart.text);
                        // You could display this text to the user if desired
                    }
                } else {
                    // Try using Imagen model as fallback
                    console.log('No image found in response, trying Imagen model...');
                    return await processImageEditWithImagen(image, prompt);
                }
            } else if (data.promptFeedback && data.promptFeedback.blockReason) {
                // Handle content filtering blocks
                throw new Error(`Your request was blocked: ${data.promptFeedback.blockReason}`);
            } else {
                throw new Error('Invalid API response format - no image was returned');
            }
        } else if (data.error) {
            throw new Error(`API Error (${data.error.code}): ${data.error.message}`);
        } else {
            throw new Error('API request failed with an unknown error');
        }
    } catch (error) {
        console.error('Error:', error);
        apiResponseText.textContent += `\n\nERROR: ${error.message}`;
        apiResponseInfo.style.display = 'block';
        alert(`Error: ${error.message || 'Failed to process image'}`);
    } finally {
        loadingIndicator.style.display = 'none';
    }
}

// Fallback to Imagen model
async function processImageEditWithImagen(image, prompt) {
    try {
        // Prepare image data
        const base64Image = image.split(',')[1]; // Remove data URL prefix
        
        // Try with a different model: Gemini 1.5 Pro instead
        const requestBody = {
            contents: [
                {
                    parts: [
                        { 
                            text: prompt + ". Edit this image according to my instructions."
                        },
                        {
                            inline_data: {
                                mime_type: "image/jpeg",
                                data: base64Image
                            }
                        }
                    ]
                }
            ],
            generation_config: {
                response_modalities: ["TEXT", "IMAGE"]
            }
        };
        
        console.log('Trying Gemini 1.5 Pro as fallback...');
        
        // Add the fallback attempt to the debug info
        apiResponseText.textContent += "\n\nTrying fallback with Gemini 1.5 Pro model...";
        
        // Make API request to Gemini 1.5 Pro
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro-latest:generateContent?key=${apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });
        
        const data = await response.json();
        console.log('Gemini 1.5 Pro Response:', data);
        
        // Update the response text with fallback results
        apiResponseText.textContent += "\n\nFallback Response:\n" + JSON.stringify(data, null, 2);
        apiResponseInfo.style.display = 'block';
        
        if (response.ok && data.candidates && data.candidates[0].content) {
            const parts = data.candidates[0].content.parts;
            const imagePart = parts.find(part => part.inline_data);
            
            if (imagePart && imagePart.inline_data) {
                // Display the edited image
                editedImage = `data:${imagePart.inline_data.mime_type};base64,${imagePart.inline_data.data}`;
                displayImage(resultPreview, editedImage);
                resultSection.style.display = 'block';
                reEditControls.style.display = 'none';
                return true;
            }
        }
        
        // If we get here, both models failed to generate an image
        throw new Error('Both models failed to generate an image. Please try a different prompt or image.');
    } catch (error) {
        console.error('Fallback error:', error);
        apiResponseText.textContent += `\n\nFALLBACK ERROR: ${error.message}`;
        apiResponseInfo.style.display = 'block';
        alert(`Error: ${error.message || 'Failed to process image with both models'}`);
        return false;
    }
}

// Download edited image
downloadButton.addEventListener('click', () => {
    if (editedImage) {
        const link = document.createElement('a');
        link.href = editedImage;
        link.download = 'edited-image.jpg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
});

// Show re-edit controls
reEditButton.addEventListener('click', () => {
    reEditControls.style.display = 'block';
});
