// DOM Elements
const imageUploadInput = document.getElementById('imageUpload');
const imagePreview = document.getElementById('imagePreview');
const editSection = document.getElementById('editSection');
const editPrompt = document.getElementById('editPrompt');
const editButton = document.getElementById('editButton');
const resultSection = document.getElementById('resultSection');
const resultPreview = document.getElementById('resultPreview');
const downloadButton = document.getElementById('downloadButton');
const reEditButton = document.getElementById('reEditButton');
const reEditControls = document.getElementById('reEditControls');
const reEditPrompt = document.getElementById('reEditPrompt');
const applyReEditButton = document.getElementById('applyReEditButton');
const loadingIndicator = document.getElementById('loadingIndicator');
const apiKeyModal = document.getElementById('apiKeyModal');
const apiKeyInput = document.getElementById('apiKeyInput');
const saveApiKey = document.getElementById('saveApiKey');

// State variables
let originalImage = null;
let editedImage = null;
let apiKey = null;

// Fetch API key from server on load
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('/api/key');
        const data = await response.json();
        
        if (response.ok && data.key) {
            apiKey = data.key;
            console.log('API key loaded from .env file');
        } else {
            console.error('Failed to load API key from server:', data.error);
            apiKeyModal.style.display = 'flex';
        }
    } catch (error) {
        console.error('Error fetching API key:', error);
        apiKeyModal.style.display = 'flex';
    }
});

// Save manually entered API key (fallback method)
saveApiKey.addEventListener('click', () => {
    const key = apiKeyInput.value.trim();
    if (key) {
        apiKey = key;
        apiKeyModal.style.display = 'none';
    } else {
        alert('Please enter a valid API key');
    }
});

// Handle image upload
imageUploadInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        const file = e.target.files[0];
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(event) {
                originalImage = event.target.result;
                displayImage(imagePreview, originalImage);
                editSection.style.display = 'block';
                resultSection.style.display = 'none';
            };
            reader.readAsDataURL(file);
        } else {
            alert('Please upload an image file');
        }
    }
});

// Display image in container
function displayImage(container, imageSrc) {
    container.innerHTML = '';
    const img = document.createElement('img');
    img.src = imageSrc;
    container.appendChild(img);
}

// Process image edit
editButton.addEventListener('click', async () => {
    const prompt = editPrompt.value.trim();
    if (!prompt) {
        alert('Please describe the changes you want to make');
        return;
    }
    
    if (!originalImage) {
        alert('Please upload an image first');
        return;
    }
    
    if (!apiKey) {
        alert('API key is missing. Please provide your Gemini API key');
        apiKeyModal.style.display = 'flex';
        return;
    }
    
    processImageEdit(originalImage, prompt);
});

// Process re-edit
applyReEditButton.addEventListener('click', async () => {
    const prompt = reEditPrompt.value.trim();
    if (!prompt) {
        alert('Please describe the additional changes');
        return;
    }
    
    processImageEdit(editedImage || originalImage, prompt);
});

// Main image processing function
async function processImageEdit(image, prompt) {
    loadingIndicator.style.display = 'flex';
    
    try {
        // Prepare image data
        const base64Image = image.split(',')[1]; // Remove data URL prefix
        
        // Prepare request body for Gemini API
        const requestBody = {
            contents: [
                {
                    parts: [
                        { text: prompt },
                        {
                            inline_data: {
                                mime_type: "image/jpeg",
                                data: base64Image
                            }
                        }
                    ]
                }
            ],
            generation_config: {
                response_modalities: ["Text", "Image"]
            }
        };
        
        // Make API request
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp-image-generation:generateContent?key=${apiKey}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            // Handle successful response
            if (data.candidates && data.candidates[0].content && data.candidates[0].content.parts) {
                // Find the image part in the response
                const imagePart = data.candidates[0].content.parts.find(part => part.inline_data);
                
                if (imagePart && imagePart.inline_data) {
                    // Display the edited image
                    editedImage = `data:${imagePart.inline_data.mime_type};base64,${imagePart.inline_data.data}`;
                    displayImage(resultPreview, editedImage);
                    resultSection.style.display = 'block';
                    reEditControls.style.display = 'none';
                } else {
                    throw new Error('No image found in response');
                }
            } else {
                throw new Error('Invalid API response format');
            }
        } else {
            throw new Error(data.error?.message || 'API request failed');
        }
    } catch (error) {
        console.error('Error:', error);
        alert(`Error: ${error.message || 'Failed to process image'}`);
    } finally {
        loadingIndicator.style.display = 'none';
    }
}

// Download edited image
downloadButton.addEventListener('click', () => {
    if (editedImage) {
        const link = document.createElement('a');
        link.href = editedImage;
        link.download = 'edited-image.jpg';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
});

// Show re-edit controls
reEditButton.addEventListener('click', () => {
    reEditControls.style.display = 'block';
});
